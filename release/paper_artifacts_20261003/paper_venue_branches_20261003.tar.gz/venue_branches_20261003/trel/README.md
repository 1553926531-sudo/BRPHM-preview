# IEEE Transactions on Reliability overlay

Status: `PREPARED_OVERLAY_PENDING_OFFICIAL_RULE_CHECK_AND_AUTHOR_METADATA`

Proposed title: **Provenance-Controlled Reliability Evaluation of Source-Label-Only Cross-Orbit RUL Transfer**

Frame the paper around reliability credibility, failure-mode-aware evaluation, source-gate risk, and reproducibility. Do not imply probabilistic reliability inference beyond the registered deterministic evidence.

Shared source: `../../en/main.tex`; shared PDF: `../../en/main.pdf`; shared evidence: `../../review/`.

Promotion requires dated, hashed verification of official T-Rel author instructions, article type/page limit, review model, PDF checker, accessibility rules, and whether this deterministic small final partition is suitable for a regular paper. No metric, split, F1 chronology, or claim may change in this overlay.
