# IEEE Transactions on Instrumentation and Measurement overlay

Status: `PREPARED_OVERLAY_PENDING_OFFICIAL_RULE_CHECK_AND_AUTHOR_METADATA`

Proposed title: **Measurement Telemetry Provenance and Source-Label-Only Route Auditing for Cross-Orbit RUL Prediction**

Frame the paper around measurement-derived telemetry contracts, sensor semantics, split provenance, hash-linked metrics, and a controlled audit protocol. Keep the tiny BAT deterministic delta and the RWA tie as bounded evidence.

Shared source: `../../en/main.tex`; shared PDF: `../../en/main.pdf`; shared evidence: `../../review/`.

Promotion requires dated, hashed verification of the official TIM scope, current template, article type, page limit, review model, PDF checker, accessibility rules, and recent scope papers. No metric, split, F1 chronology, or claim may change in this overlay.
