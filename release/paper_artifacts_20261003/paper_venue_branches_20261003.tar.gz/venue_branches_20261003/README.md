# Multi venue IEEE branch pack

Generated 2026-10-03. This pack keeps three independent IEEE submission routes ready while the exact venue, article type, author metadata, and official checker rules are still being verified.

The source of record is `../en/main.tex`; the PDF and F1-F10 evidence are shared by hash. These overlays do not claim acceptance, current page-limit compliance, or venue-specific PDF/accessibility compliance.

## Branches

| Branch | Venue | Editorial emphasis | Promotion gate |
|---|---|---|---|
| `tim/` | IEEE Transactions on Instrumentation and Measurement | Measurement telemetry semantics, provenance, split contracts, and reproducible evaluation | Verify official scope, template, article type, page limit, review model, PDF checker, and accessibility rules |
| `trel/` | IEEE Transactions on Reliability | Reliability credibility, source-gate risk, and provenance-controlled RUL evaluation | Verify official author instructions and whether the deterministic small final partition is acceptable |
| `taes/` | IEEE Transactions on Aerospace and Electronic Systems | Spacecraft telemetry and cross-orbit evaluation with the simulator seam explicitly bounded | Verify official author instructions and aerospace evidence expectations |

All branches inherit the same immutable contract:

- Historical six-fold counts `5,4,3,1,3,0` are development/diagnostic evidence after the F1 provenance finding.
- The separately registered LEO600 partition was frozen before final-label access and evaluated once.
- BAT has five units/125 windows with RMSE delta `-9.530122000667163e-06` cycles and MAE delta `-9.132921695798046e-06` cycles.
- RWA has one usable unit/one window and ties the reference.
- These results support a deterministic tolerance gate only; they do not establish significance, practical relevance, or population generalization.
- The implemented information regime is label-free target-input/transductive: orbit identity and the earliest unlabeled target window are used; target labels are not used.

Before any branch becomes submission-ready, confirm author names, affiliations, corresponding author, ORCID, funding, COI, article type, blind mode, official template/checker, and accessibility result. Do not change F1 chronology, split membership, frozen receipts, gate arithmetic, metric values, or access sealed/A1/B1/canonical/production/competition assets.
