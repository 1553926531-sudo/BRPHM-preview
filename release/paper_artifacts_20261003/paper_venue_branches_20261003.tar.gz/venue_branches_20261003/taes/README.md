# IEEE Transactions on Aerospace and Electronic Systems overlay

Status: `PREPARED_OVERLAY_PENDING_OFFICIAL_RULE_CHECK_AND_AUTHOR_METADATA`

Proposed title: **Auditable Cross-Orbit RUL Evaluation for Simulated Spacecraft Battery and Reaction-Wheel Telemetry**

Frame the paper around spacecraft telemetry, cross-orbit transfer, and explicit simulator seam limitations. Preserve the approximately 79-second period mismatch and the one-observation RWA bound in all application claims.

Shared source: `../../en/main.tex`; shared PDF: `../../en/main.pdf`; shared evidence: `../../review/`.

Promotion requires dated, hashed verification of official TAES author instructions, article type/page limit, review model, PDF checker, accessibility rules, and aerospace evidence expectations. No metric, split, F1 chronology, or claim may change in this overlay.
