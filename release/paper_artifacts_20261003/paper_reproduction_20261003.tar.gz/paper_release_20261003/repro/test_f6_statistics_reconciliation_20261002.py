from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
F5_SCRIPT = ROOT / "work/paper/repro/build_f5_precision_ledger.py"
F6_SCRIPT = ROOT / "work/paper/repro/build_f6_statistics_20261002.py"
OUTPUT = ROOT / "work/paper/review/f6_statistics_20261002/f6_statistics_reconciled.json"


def test_f6_separates_frozen_benchmark_uncertainty_from_replay_sensitivity() -> None:
    subprocess.run([sys.executable, str(F5_SCRIPT)], cwd=ROOT, check=True, capture_output=True, text=True)
    subprocess.run([sys.executable, str(F6_SCRIPT)], cwd=ROOT, check=True, capture_output=True, text=True)

    report = json.loads(OUTPUT.read_text(encoding="utf-8"))
    assert report["unit_pairing"]["frozen_reference_pairing_available"] is False
    assert report["unit_pairing"]["replay_csv_role"] == "DIAGNOSTIC_REPLAY_ONLY"
    assert report["frozen_fold_benchmark"]["fold_count"] == 6
    assert report["frozen_fold_benchmark"]["unit_cluster_bootstrap"]["window_counts_preserved"] is True
    assert report["replay_control_sensitivity"]["paired_unit_tests_are_diagnostic_only"] is True
    assert report["replay_control_sensitivity"]["multiplicity_family_size"] == 12
    assert report["seed_sensitivity"]["seed_count"] == 3
    assert report["seed_sensitivity"]["inferential_status"] == "DESCRIPTIVE_ONLY"
