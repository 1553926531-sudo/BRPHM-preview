# Paper Artifact Index

Generated: 2026-10-02T18:32:06Z

This index covers only the isolated paper tree. It excludes sealed/A1/B1/canonical/production/competition assets.

| Artifact | Path | SHA-256 | Role |
|---|---|---|---|
| main.log | `work/paper/en/main.log` | `d4b5d43fb859ccbcc3b2bc58376627ca3ed1a52d4c0f04c3bdc205b708a5b84a` | hash-linked evidence/input |
| main.pdf | `work/paper/en/main.pdf` | `80dc05172481586a629449cf3df595fea0fda48bfe1d5e953f6fbca6875511db` | hash-linked evidence/input |
| main.tex | `work/paper/en/main.tex` | `4dc54e2a8ccd3aa087344ae52737b5f9f1bc5bb97faa9926c1d0aa6cf5d33621` | hash-linked evidence/input |
| main_extracted.txt | `work/paper/en/main_extracted.txt` | `f4fb582c35939b8a81bc4787c862620671aa8c86d0fab598b26a44c5a8adf1b1` | hash-linked evidence/input |
| evaluation_protocol.pdf | `work/paper/figures/evaluation_protocol.pdf` | `b7ee9e3609d53c6b8e53451f8f96fcec41f816d2ecbee00a68820b612242cac6` | hash-linked evidence/input |
| evaluation_protocol.png | `work/paper/figures/evaluation_protocol.png` | `21c3a4611c82e4904d03cdd36f0d36208bc3ee177a8798e57ca0c59973090e97` | hash-linked evidence/input |
| formal_deltas.pdf | `work/paper/figures/formal_deltas.pdf` | `52afb96f9d247585a31183c6cc352e349d494619c70a089f579fa7159a44189d` | hash-linked evidence/input |
| formal_deltas.png | `work/paper/figures/formal_deltas.png` | `69b075499f1e9f6c924c7ea2dad13f74e561e5004c8a79b67d7f179c3a9bab3e` | hash-linked evidence/input |
| method_progression.pdf | `work/paper/figures/method_progression.pdf` | `4c1b9f2ba2c0723e01a572278b8ba6b4749584708f4a9fef237704f148a0cf63` | hash-linked evidence/input |
| method_progression.png | `work/paper/figures/method_progression.png` | `1a6d031b8c68bb19f97a0bcc3e1ef310661854a6cb915a2aaecf6c415b8efac6` | hash-linked evidence/input |
| relative_rmse.pdf | `work/paper/figures/relative_rmse.pdf` | `c6d197c3b5922a881f6c4f21e646243de05415847ac2b4533d1ec0abe5272cf4` | hash-linked evidence/input |
| relative_rmse.png | `work/paper/figures/relative_rmse.png` | `57dd72d113629582ac4a5a9ada38c844bee786e793dc9f74b0b5a9112339c43d` | hash-linked evidence/input |
| README.md | `work/paper/repro/README.md` | `b6572b56af27ffce89bc90b1169bfe3b04789401ae44b40ac8e5bdb0e4862cb0` | hash-linked evidence/input |
| analyze_f8_cluster_residuals_20261002.py | `work/paper/repro/analyze_f8_cluster_residuals_20261002.py` | `de9a2503825c4802941f3ae1dc5d7f935d755c5acce5239fece63984349d57bd` | hash-linked evidence/input |
| build_f2_dataset_split_manifest.py | `work/paper/repro/build_f2_dataset_split_manifest.py` | `6a1f6ab9db7e22d12ce81d52d3580b7c5da0dbb9e72383a77bf2beef0d9476fc` | hash-linked evidence/input |
| build_f3_method_ledger.py | `work/paper/repro/build_f3_method_ledger.py` | `416d3c6aecdb2812315b63d9d2e94f07be0f8afe0cfe502e1acb68c324d8d885` | hash-linked evidence/input |
| build_f4_route_ledger.py | `work/paper/repro/build_f4_route_ledger.py` | `fd6782e851a300794d77824aaa17cf9ad266294217174ba7e74c2c537e846959` | hash-linked evidence/input |
| build_f5_precision_ledger.py | `work/paper/repro/build_f5_precision_ledger.py` | `d844dbadb4d5c78b1db5741df6df2a5c555655fe6ffefe23511bbee0eaa625cc` | hash-linked evidence/input |
| build_f6_statistics_20261002.py | `work/paper/repro/build_f6_statistics_20261002.py` | `a482a86c601727302352adb852dfd4bc051211091ee1c43b5f01fd3d75861ef7` | hash-linked evidence/input |
| build_f8_evidence_ledger_20261002.py | `work/paper/repro/build_f8_evidence_ledger_20261002.py` | `09a1c5f8ec1029e5eb896cc455256911b09547f7c165d93df21cbf6a56b91d1c` | hash-linked evidence/input |
| export_f8_source_residuals_20261002.py | `work/paper/repro/export_f8_source_residuals_20261002.py` | `9e07d3841ccfb5ac61902b9836d442d08741e35a58cfdb651e01a7614ddb0529` | hash-linked evidence/input |
| generate_figures.py | `work/paper/repro/generate_figures.py` | `bae0f590311aa4270d82547e3f7ec64d7186cab518889709afbf007aabd4a43a` | hash-linked evidence/input |
| f1_closeout_20261002.md | `work/paper/review/f1_closeout_20261002.md` | `eb94a1834ef5f3fea9c4a4865cbe6333b9a3394203d68af8284a285daf1957f3` | hash-linked evidence/input |
| f1_evidence_ledger.json | `work/paper/review/f1_evidence_ledger.json` | `b57ecd4c855c8c7f1d19fbc6a7932148cd760234de19d92183b94fce4c279443` | hash-linked evidence/input |
| f2_evidence_ledger.json | `work/paper/review/f2_evidence_ledger.json` | `7d99a6fd78885c89791a6493d36c767ce3d50b90ea691701a76eaaf056fa287a` | hash-linked evidence/input |
| f3_evidence_ledger.json | `work/paper/review/f3_method_20261002/f3_evidence_ledger.json` | `d5050006fead49e47f1d258bdd99325833a87c9285272c6e289f0b1a9e340141` | hash-linked evidence/input |
| f4_evidence_ledger.json | `work/paper/review/f4_route_20261002/f4_evidence_ledger.json` | `96b98846b0eb5a3aa0af3331ff302ef308ad129569405eab86bf6b04d96b3585` | hash-linked evidence/input |
| f5_evidence_ledger.json | `work/paper/review/f5_unit_metrics_20261002/f5_evidence_ledger.json` | `e8b64844a5ba25ec119e367126bd5ee8ba0e584ae671c1e1e7e507e34feaf7d2` | hash-linked evidence/input |
| f6_evidence_ledger_reconciled.md | `work/paper/review/f6_statistics_20261002/f6_evidence_ledger_reconciled.md` | `18bfea5c41496718a1aa5fffd044af7c657bd8139505940ef943333634808b5c` | hash-linked evidence/input |
| f6_statistics_reconciled.json | `work/paper/review/f6_statistics_20261002/f6_statistics_reconciled.json` | `4f02449ba60328d53c33800cfe2dad041e7c47566a2364218dacc09670d01c0c` | hash-linked evidence/input |
| f7_literature_evidence_20261002.md | `work/paper/review/f7_literature_evidence_20261002.md` | `083b6401d49ac84cb75e44cc3c739b295ed0021a616d1730001f04e0e0189ae6` | hash-linked evidence/input |
| f8_evidence_ledger.json | `work/paper/review/f8_source_gate_20261002/f8_evidence_ledger.json` | `6c6c44a33b045571d38c4487bc0528bfa4b883ead4b104d86163442c189b5fd0` | hash-linked evidence/input |
| pdf_build_verification_20261003.json | `work/paper/review/pdf_build_verification_20261003.json` | `eac5b565542af116d2fad796a66cb4fbe7235a374f6be0d5aaa2be6b22a07169` | hash-linked evidence/input |
| pdf_build_verification_20261003.md | `work/paper/review/pdf_build_verification_20261003.md` | `b14b9a1bdd8a985174119a68e8e90fd315612cb12307cf868fcb0c05c18b0364` | hash-linked evidence/input |
| q1_venue_research_20261003.md | `work/paper/review/q1_venue_research_20261003.md` | `c6c2fae8cdc4fbd97e75816bcb63e95ddaf48c8bd98c3be6f2b2821d7854a70e` | hash-linked evidence/input |
| rebuild_pdf_verification_20261003.py | `work/paper/review/rebuild_pdf_verification_20261003.py` | `7450bbf8ac039b6f8e2db49ca3047120be00aea1e6afa301a3280ab269d513f6` | hash-linked evidence/input |
| venue_research_20261002.md | `work/paper/review/venue_research_20261002.md` | `0e0986230b399dcc03c2b65d602e9f39c593cf0ea9308e3e63405e94bc00ceb5` | hash-linked evidence/input |
| venue_strategy_20261003.md | `work/paper/review/venue_strategy_20261003.md` | `fd5cb28fbeac8e87b59e043124bba8cc29091da03f484b115bf306516f94379d` | hash-linked evidence/input |

## Primary deliverables

- English LaTeX: `work/paper/en/main.tex`
- English PDF: `work/paper/en/main.pdf`
- Reproduction README and runners: `work/paper/repro/`
- F1–F8 ledgers: `work/paper/review/`
- F9 ledger: `work/paper/review/f9_evidence_ledger.json` and `.md`
- F10 report: `work/paper/review/f10_pdf_production_report.json` and `.md`
- Machine manifest: `work/paper/review/reproduction_manifest.json`
- IEEE checklist: `work/paper/review/ieee_checklist_1_1_1_7.json` and `.md`
- Response letter: `work/paper/review/response_letter.md`
- Venue strategy and SCI-Q1 fallback ledger: `work/paper/review/venue_strategy_20261003.md` and `q1_venue_research_20261003.md`

## Release boundary

The paper-specific public release, DOI, author metadata, funding/COI confirmation, exact venue, article type, PDF eXpress, and accessibility check remain pending. ModelScope data are referenced by URL/commit and are not duplicated.
